VERSION = (2, 1, 21)

__version__ = '.'.join(map(str, VERSION))
